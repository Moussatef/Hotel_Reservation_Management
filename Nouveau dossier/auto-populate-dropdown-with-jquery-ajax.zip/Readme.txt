Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/auto-populate-dropdown-with-jquery-ajax/

Instructions -

1. Import attached users.sql and department.sql file in your MySQL database.
2. Update config.php file.